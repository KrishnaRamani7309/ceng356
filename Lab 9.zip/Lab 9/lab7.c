#include "header.h"

/* Fill the data section into simulated memory */
void setupDataMemory(char *base_address,
                     unsigned int offset,
                     char *datasection,
                     unsigned int numberOfBytes)
{
    unsigned int i;

    for (i = 0; i < numberOfBytes; i++)
    {
        *(base_address + offset + i) = (unsigned char)datasection[i];
    }
}

/* Build I-type instruction: opcode | rs | rt | immediate */
unsigned int buildIInstruction(unsigned char opcode,
                               unsigned char rs,
                               unsigned char rt,
                               int immediate)
{
    unsigned int machineCode = 0;

    machineCode |= ((unsigned int)(opcode & 0x3F)) << 26;
    machineCode |= ((unsigned int)(rs & 0x1F)) << 21;
    machineCode |= ((unsigned int)(rt & 0x1F)) << 16;
    machineCode |= ((unsigned int)immediate & 0xFFFF);

    return machineCode;
}

/* Build J-type instruction: opcode | address */
unsigned int buildJInstruction(unsigned char opcode,
                               int immediate)
{
    unsigned int machineCode = 0;

    machineCode |= ((unsigned int)(opcode & 0x3F)) << 26;
    machineCode |= ((unsigned int)immediate & 0x03FFFFFF);

    return machineCode;
}

/* Build R-type instruction: opcode | rs | rt | rd | shamt | function */
unsigned int buildRInstruction(unsigned char opcode,
                               unsigned char rs,
                               unsigned char rt,
                               unsigned char rd,
                               unsigned char shamt,
                               unsigned char function)
{
    unsigned int machineCode = 0;

    machineCode |= ((unsigned int)(opcode & 0x3F)) << 26;
    machineCode |= ((unsigned int)(rs & 0x1F)) << 21;
    machineCode |= ((unsigned int)(rt & 0x1F)) << 16;
    machineCode |= ((unsigned int)(rd & 0x1F)) << 11;
    machineCode |= ((unsigned int)(shamt & 0x1F)) << 6;
    machineCode |= ((unsigned int)(function & 0x3F));

    return machineCode;
}

/* Store all supported instructions into instruction memory */
void setupInstructionMemory(char *base_memory_address,
                            int codeOffset,
                            MIPS_Instruction *instructionStorage)
{
    int i = 0;
    unsigned char opcode = 0;
    unsigned char function = 0;
    unsigned int machineCode = 0;
    int branchImmediate = 0;

    while (1)
    {
        if (strcmp(instructionStorage[i].instruction, "la") == 0)
        {
            opcode = 0b101111;

            machineCode = buildIInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            instructionStorage[i].immediate);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
            instructionStorage[i].machineCode = machineCode;
        }
        else if (strcmp(instructionStorage[i].instruction, "lb") == 0)
        {
            opcode = 0b100000;

            machineCode = buildIInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            instructionStorage[i].immediate);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
            instructionStorage[i].machineCode = machineCode;
        }
        else if (strcmp(instructionStorage[i].instruction, "bge") == 0)
        {
            opcode = 0b110010;

            branchImmediate = instructionStorage[i].address - (i + 1);

            machineCode = buildIInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            branchImmediate);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
            instructionStorage[i].machineCode = machineCode;
        }
        else if (strcmp(instructionStorage[i].instruction, "lw") == 0)
        {
            opcode = 0b100011;

            machineCode = buildIInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            instructionStorage[i].immediate);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
            instructionStorage[i].machineCode = machineCode;
        }
        else if (strcmp(instructionStorage[i].instruction, "sw") == 0)
        {
            opcode = 0b101011;

            machineCode = buildIInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            instructionStorage[i].immediate);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
            instructionStorage[i].machineCode = machineCode;
        }
        else if (strcmp(instructionStorage[i].instruction, "add") == 0)
        {
            opcode = 0b000000;
            function = 0b100000;

            machineCode = buildRInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            instructionStorage[i].rd,
                                            instructionStorage[i].shamt,
                                            function);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
            instructionStorage[i].machineCode = machineCode;
        }
        else if (strcmp(instructionStorage[i].instruction, "addi") == 0)
        {
            opcode = 0b001000;

            machineCode = buildIInstruction(opcode,
                                            instructionStorage[i].rs,
                                            instructionStorage[i].rt,
                                            instructionStorage[i].immediate);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
            instructionStorage[i].machineCode = machineCode;
        }
        else if (strcmp(instructionStorage[i].instruction, "j") == 0)
        {
            opcode = 0b000010;

            machineCode = buildJInstruction(opcode,
                                            instructionStorage[i].address);

            write_dword(base_memory_address, codeOffset + i * 4, machineCode);
            instructionStorage[i].machineCode = machineCode;
        }
        else if ((strcmp(instructionStorage[i].instruction, "syscall") == 0) ||
                 (strcmp(instructionStorage[i].instruction, "END") == 0))
        {
            break;
        }

        i++;
    }
}

void loadCodeToMem(char *mem)
{
    setupDataMemory(mem, DATASECTION, Data_storage, totalDataByte);
    setupInstructionMemory(mem, CODESECTION, Instruction_storage);

    puts("\n---- Code Section ----\n");
    memory_dump(mem, CODESECTION, 256);

    puts("\n---- Data Section ----\n");
    memory_dump(mem, DATASECTION, 256);
}