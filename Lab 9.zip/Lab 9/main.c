 /*
 ============================================================================
 Name        : main.c
 Author      : Austin Tian
 Revised by  :
 Version     :
 Copyright   : Copyright 2023
 Description : main code in C
 ============================================================================
 */

#include "header.h"
#include "lab8header.h"

int main(int argc, char *argv[]) {
    char *mem = NULL;
    FILE *fp = NULL;
    int stopChar;

    if (argc < 2) {
        puts("\nIncorrect number of arguments.");
        puts("Usage: ProgramName.exe MIPSCode.asm \n");
        stopChar = getchar();
        return EXIT_FAILURE;
    }

    if ((fp = fopen(argv[1], "r")) == NULL) {
        printf("Input file could not be opened.");
        stopChar = getchar();
        return EXIT_FAILURE;
    }

    parse_MIPS(fp);
    fclose(fp);

    mem = init_memory();
    stopChar = getchar();

    puts("----Lab 7 Code Starts to Parse the ASM Code----");
    loadCodeToMem(mem);
    stopChar = getchar();

    CPU((unsigned char *)mem);

    free_memory(mem);
    return 0;
}