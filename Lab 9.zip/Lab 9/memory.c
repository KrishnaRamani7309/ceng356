#include "header.h"
#include <time.h>

char *menu =    "\n" \
                " ***********Please select the following options**********************\n" \
                " *    This is the memory operation menu (Lab 6)                     *\n" \
                " ********************************************************************\n" \
                " *    1. Write a double-word (32-bit) to the memory                 *\n"  \
                " ********************************************************************\n" \
                " *    2. Read a byte (8-bit) data from the memory                   *\n" \
                " *    3. Read a double-word (32-bit) data from the memory           *\n" \
                " ********************************************************************\n" \
                " *    4. Generate a memory dump from any memory location            *\n" \
                " ********************************************************************\n" \
                " *    e. To Exit, Type 'e'  or 'E'                                  *\n" \
                " ********************************************************************\n";

unsigned char rand_generator()
{
    return (unsigned char)(rand() % 256);
}

void free_memory(char *base_address)
{
    free(base_address);
    return;
}

/* Lab 7 and later: initialize memory with zeros */
char *init_memory()
{
    char *mem = malloc(MEM_SIZE);

    if (mem == NULL)
    {
        puts("Memory allocation failed.");
        exit(EXIT_FAILURE);
    }

    memset(mem, 0, MEM_SIZE);
    return mem;
}

void write_byte(char *base_address, int offset, unsigned char byte_data)
{
    if (offset < 0 || offset >= MEM_SIZE)
    {
        puts("Invalid offset address for byte write.");
        return;
    }

    ((unsigned char *)base_address)[offset] = byte_data;
}

void write_dword(char *base_address, int offset, unsigned int dword_data)
{
    if (offset < 0 || offset + 3 >= MEM_SIZE)
    {
        puts("Invalid offset address for double-word write.");
        return;
    }

    ((unsigned char *)base_address)[offset]     = (unsigned char)(dword_data & 0xFF);
    ((unsigned char *)base_address)[offset + 1] = (unsigned char)((dword_data >> 8) & 0xFF);
    ((unsigned char *)base_address)[offset + 2] = (unsigned char)((dword_data >> 16) & 0xFF);
    ((unsigned char *)base_address)[offset + 3] = (unsigned char)((dword_data >> 24) & 0xFF);

    printf("DWORD 0x%08X was written to offset 0x%X\n", dword_data, offset);
}

unsigned char read_byte(char *base_address, int offset)
{
    unsigned char value;

    if (offset < 0 || offset >= MEM_SIZE)
    {
        puts("Invalid offset address for byte read.");
        return 0;
    }

    value = ((unsigned char *)base_address)[offset];
    printf("BYTE at offset 0x%X = 0x%02X\n", offset, value);
    return value;
}

unsigned int read_dword(char *base_address, int offset)
{
    unsigned int value;

    if (offset < 0 || offset + 3 >= MEM_SIZE)
    {
        puts("Invalid offset address for double-word read.");
        return 0;
    }

    value =  ((unsigned int)((unsigned char *)base_address)[offset]) |
            (((unsigned int)((unsigned char *)base_address)[offset + 1]) << 8) |
            (((unsigned int)((unsigned char *)base_address)[offset + 2]) << 16) |
            (((unsigned int)((unsigned char *)base_address)[offset + 3]) << 24);

    printf("DWORD at offset 0x%X = 0x%08X\n", offset, value);
    return value;
}

void memory_dump(char *base_address, int offset, unsigned int dumpsize)
{
    unsigned int i, j;
    unsigned int start, end;
    unsigned char current_byte;

    if (offset < 0 || offset >= MEM_SIZE)
    {
        puts("Invalid offset address for memory dump.");
        return;
    }

    if (dumpsize < MIN_DUMP_SIZE || dumpsize > MEM_SIZE)
        dumpsize = MIN_DUMP_SIZE;

    start = (unsigned int)offset;

    if (start + dumpsize > MEM_SIZE)
        dumpsize = MEM_SIZE - start;

    end = start + dumpsize;

    for (i = start; i < end; i += DUMP_LINE)
    {
        printf("%p: ", (void *)(base_address + i));

        for (j = 0; j < DUMP_LINE; j++)
        {
            if (i + j < end)
                printf("%02X ", (unsigned char)base_address[i + j]);
            else
                printf("   ");
        }

        printf(" --- ");

        for (j = 0; j < DUMP_LINE; j++)
        {
            if (i + j < end)
            {
                current_byte = (unsigned char)base_address[i + j];

                if (current_byte >= 0x20 && current_byte <= 0x7E)
                    printf("%c", current_byte);
                else
                    printf(".");
            }
        }

        printf("\n");
    }

    return;
}

void setup_memory()
{
    char *mem = init_memory();
    char options = 0;
    unsigned int offset, dumpsize;
    char tempchar;
    unsigned int dword_data;

    do
    {
        if (options != 0x0a)
        {
            puts(menu);
            printf("\nThe base address of your memory is: %p (HEX)\n", (void *)mem);
            puts("Please make a selection:");
        }

        options = getchar();

        switch (options)
        {
            case '1':
                puts("Please input your memory's offset address (in HEX):");
                scanf("%x", &offset);

                puts("Please input your DOUBLE WORD data to be written (in HEX):");
                scanf("%x", &dword_data);

                write_dword(mem, offset, dword_data);
                continue;

            case '2':
                puts("Please input your memory's offset address (in HEX):");
                scanf("%x", &offset);

                read_byte(mem, offset);
                continue;

            case '3':
                puts("Please input your memory's offset address (in HEX):");
                scanf("%x", &offset);

                read_dword(mem, offset);
                continue;

            case '4':
                puts("Please input your memory's offset address (in HEX, should be a multiple of 0x10h):");
                scanf("%x", &offset);

                puts("Please input the size of the memory to be dumped (a number between 256 and 1024):");
                scanf("%u", &dumpsize);

                memory_dump(mem, offset, dumpsize);
                continue;

            case 'e':
            case 'E':
                puts("Code finished, press any key to exit");

                free_memory(mem);

                while ((tempchar = getchar()) != '\n' && tempchar != EOF);

                tempchar = getchar();
                return;

            default:
                continue;
        }

    } while (1);
}