/*
 * Lab 8 / Lab 9 CPU functions
 * Student comments added as required by lab instructions.
 */

#include <stdio.h>
#include <stdlib.h>
#include "header.h"
#include "lab8header.h"

extern char *regNameTab[N_REG];
extern int regFile[N_REG];

unsigned int PCRegister = 0;

/*
 * CPU starts from code section, fetches one instruction,
 * decodes it, executes it, and stops when machineCode becomes 0.
 */
void CPU(unsigned char *mem){
    unsigned int machineCode = 0;
    unsigned char opcode = 0;

    PCRegister = CODESECTION;

    do{
        printf("\nPC:%X\n", PCRegister);

        machineCode = CPU_fetchCode((char *)mem, PCRegister);

        if (machineCode == 0)
            break;

        opcode = CPU_Decode(machineCode);
        printf("Decoded Opcode is: %02X.\n", opcode);

        /* Lab 9 execution enabled */
        CPU_Execution(opcode, machineCode, (char *)mem);

    } while (1);

    printRegisterFiles();
    printDataMemoryDump((char *)mem);
}

/*
 * Fetch 4 bytes from memory and rebuild one 32-bit instruction.
 * write_dword() stores instructions in little-endian format,
 * so fetch must reconstruct them in little-endian too.
 */
unsigned int CPU_fetchCode(char *mem, int codeOffset){
    unsigned int machineCode = 0;

    machineCode =
        ((unsigned int)(unsigned char)mem[codeOffset]) |
        (((unsigned int)(unsigned char)mem[codeOffset + 1]) << 8) |
        (((unsigned int)(unsigned char)mem[codeOffset + 2]) << 16) |
        (((unsigned int)(unsigned char)mem[codeOffset + 3]) << 24);

    return machineCode;
}

/*
 * Decode instruction:
 * - For I-type and J-type, return opcode
 * - For R-type, opcode is 0, so return funct field
 */
unsigned char CPU_Decode(unsigned int machineCode){
    unsigned char opcode = 0;

    opcode = (unsigned char)((machineCode >> 26) & 0x3F);

    if (opcode == 0){
        return (unsigned char)(machineCode & 0x3F);
    }

    return opcode;
}

/*
 * Lab 9: execute the instructions used in MIPS.asm
 * Supported instructions:
 * la, add, lb, bge, lw, sw, addi, j
 */
void CPU_Execution(unsigned char opcode, unsigned int machineCode, char *mem){
    unsigned char rs = 0;
    unsigned char rt = 0;
    unsigned char rd = 0;
    short immediate = 0;
    unsigned int address = 0;

    rs = (machineCode >> 21) & 0x1F;
    rt = (machineCode >> 16) & 0x1F;
    rd = (machineCode >> 11) & 0x1F;
    immediate = (short)(machineCode & 0xFFFF);
    address = machineCode & 0x03FFFFFF;

    switch (opcode)
    {
        case 0b101111:   /* la */
            /* IMPORTANT: load the real data-section address, not only the offset */
            regFile[rt] = DATASECTION + (unsigned short)(machineCode & 0xFFFF);
            PCRegister += 4;

            if (DEBUG_CODE){
                printf("Code Executed: la\n");
                printf("%s = 0x%08X\n", regNameTab[rt], (unsigned int)regFile[rt]);
            }
            break;

        case 0b100000:   /* add funct (R-type) OR lb opcode */
            if (((machineCode >> 26) & 0x3F) == 0){
                /* add */
                regFile[rd] = regFile[rs] + regFile[rt];
                PCRegister += 4;

                if (DEBUG_CODE){
                    printf("Code Executed: add\n");
                    printf("%s = 0x%08X\n", regNameTab[rd], (unsigned int)regFile[rd]);
                }
            }
            else{
                /* lb */
                regFile[rt] = (signed char)read_byte(mem, regFile[rs] + immediate);
                PCRegister += 4;

                if (DEBUG_CODE){
                    printf("Code Executed: lb\n");
                    printf("%s = 0x%08X\n", regNameTab[rt], (unsigned int)regFile[rt]);
                }
            }
            break;

        case 0b110010:   /* bge */
            if (regFile[rs] >= regFile[rt]){
                PCRegister = PCRegister + 4 + (immediate * 4);

                if (DEBUG_CODE){
                    printf("Code Executed: bge (branch taken)\n");
                    printf("PC Register = 0x%08X\n", PCRegister);
                }
            }
            else{
                PCRegister += 4;

                if (DEBUG_CODE){
                    printf("Code Executed: bge (branch not taken)\n");
                    printf("PC Register = 0x%08X\n", PCRegister);
                }
            }
            break;

        case 0b100011:   /* lw */
            regFile[rt] = read_dword(mem, regFile[rs] + immediate);
            PCRegister += 4;

            if (DEBUG_CODE){
                printf("Code Executed: lw\n");
                printf("%s = 0x%08X\n", regNameTab[rt], (unsigned int)regFile[rt]);
            }
            break;

        case 0b101011:   /* sw */
            write_dword(mem, regFile[rs] + immediate, regFile[rt]);
            PCRegister += 4;

            if (DEBUG_CODE){
                printf("Code Executed: sw\n");
                printf("Stored 0x%08X to memory offset 0x%X\n",
                       (unsigned int)regFile[rt], regFile[rs] + immediate);
            }
            break;

        case 0b001000:   /* addi */
            regFile[rt] = regFile[rs] + immediate;
            PCRegister += 4;

            if (DEBUG_CODE){
                printf("Code Executed: addi\n");
                printf("%s = 0x%08X\n", regNameTab[rt], (unsigned int)regFile[rt]);
            }
            break;

        case 0b000010:   /* j */
            PCRegister = address * 4;

            if (DEBUG_CODE){
                printf("Code Executed: j\n");
                printf("PC Register = 0x%08X\n", PCRegister);
            }
            break;

        default:
            printf("Wrong instruction! You need to fix this instruction %02X %08X\n",
                   opcode, machineCode);
            system("PAUSE");
            exit(3);
            break;
    }

    /* Keep $zero always zero */
    regFile[0] = 0;
}

/*
 * Print all registers.
 */
void printRegisterFiles(){
    int i;

    printf("\n========== Register File Dump ==========\n");
    for (i = 0; i < N_REG; i++){
        printf("%-6s = 0x%08X\n", regNameTab[i], (unsigned int)regFile[i]);
    }
}

/*
 * Dump first 256 bytes from data section.
 */
void printDataMemoryDump(char *mem){
    printf("\n========== Data Memory Dump (First 256 Bytes) ==========\n");
    memory_dump(mem, DATASECTION, 256);
}