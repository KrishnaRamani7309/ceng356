#ifndef LAB8HEADER_H
#define LAB8HEADER_H

unsigned int CPU_fetchCode(char *mem, int codeOffset);
unsigned char CPU_Decode(unsigned int machineCode);
void CPU(unsigned char *mem);
void CPU_Execution(unsigned char opcode, unsigned int machineCode, char *mem);
void printRegisterFiles();
void printDataMemoryDump(char *mem);
extern unsigned int PCRegister;

#endif /* LAB8HEADER_H */