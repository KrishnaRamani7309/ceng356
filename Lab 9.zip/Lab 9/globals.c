
#include "header.h"

MIPS_Instruction Instruction_storage[MAX_SIZE];
int regFile[N_REG] = {0};
char Data_storage[MAX_SIZE] = {0};
unsigned int totalDataByte = 0;
labelType labelTab[MAX_LABEL];
